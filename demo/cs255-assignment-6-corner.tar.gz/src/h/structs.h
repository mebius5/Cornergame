#ifndef CORNERGAME_STRUCTS_H
#define CORNERGAME_STRUCTS_H

struct Texture {
    SDL_Texture* sdlTexture;
    int width;
    int height;
};

#endif
