#include "collisionComponent.h"

BombCollisionComponent::BombCollisionComponent(Entity* entity) :
    DynamicCollisionComponent(entity),
    exploded(false) {
}

void BombCollisionComponent::explode() {
    if (this->exploded)
        return;
    this->exploded = true;
    static_cast<OneTimeAnimationComponent*>(this->entity->art)->startAnimation();
    this->entity->x -= this->entity->width;
    this->entity->y -= this->entity->height;
    this->entity->width *= 3;
    this->entity->height *= 3;
    this->entity->drawX = this->entity->width/2 - this->entity->drawWidth/2;
    this->entity->drawY = this->entity->height/2 - this->entity->drawHeight/2;
}

void BombCollisionComponent::onEntityCollision(DynamicCollisionComponent* otherComp) {
    if (otherComp->entity->health) {
        this->entity->physics->freeze();
        this->entity->physics->target = NULL;
        this->explode();
        otherComp->entity->health->takeDamage(50);
        otherComp->entity->actionState = ACTION_DAMAGE;
    }
}

void BombCollisionComponent::onStaticCollision(StaticCollisionComponent* otherComp) {
    if (dynamic_cast<TerrainCollisionComponent*>(otherComp)) {
        this->entity->physics->freeze();
        this->entity->physics->target = NULL;
        this->explode();
    }
}
