#ifndef CORNERGAME_STATS_COMPONENT_H
#define CORNERGAME_STATS_COMPONENT_H

class StatsComponent {
public:
    StatsComponent();
};

#endif //CORNERGAME_STATS_COMPONENT_H
