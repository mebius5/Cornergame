#ifndef CORNERGAME_PHYSICS_COMPONENT_H
#define CORNERGAME_PHYSICS_COMPONENT_H

#include "component.h"

class PhysicsComponent : public Component{
public:
    PhysicsComponent();
};

#endif
