#include "inputComponent.h"

InputComponent::InputComponent(Entity * entity) {
    this->entity = entity;
}