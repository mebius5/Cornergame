#include "physicsComponent.h"

PhysicsComponent::PhysicsComponent() {
    
}
