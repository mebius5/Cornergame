#include "statsComponent.h"

StatsComponent::StatsComponent() {

}
