#ifndef CORNERGAME_PHYSICS_COMPONENT_H
#define CORNERGAME_PHYSICS_COMPONENT_H

class PhysicsComponent {
public:
    PhysicsComponent();
};

#endif
